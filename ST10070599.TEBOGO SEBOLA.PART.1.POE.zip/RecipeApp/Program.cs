﻿using System;

namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter the number of ingredients: ");
            int numIngredients = Convert.ToInt32(Console.ReadLine());

            recipe.Ingredients = new Ingredient[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                string name = Console.ReadLine();
                Console.Write($"Enter ingredient {i + 1} quantity: ");
                double quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write($"Enter ingredient {i + 1} unit: ");
                string unit = Console.ReadLine();

                recipe.Ingredients[i] = new Ingredient(name, quantity, unit);
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = Convert.ToInt32(Console.ReadLine());

            recipe.Steps = new Step[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1} description: ");
                string description = Console.ReadLine();

                recipe.Steps[i] = new Step(i + 1, description);
            }

            Console.WriteLine($"Recipe: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("Steps:");
            foreach (Step step in recipe.Steps)
            {
                Console.WriteLine($"Step {step.Number}: {step.Description}");
            }

            recipe.ScaleIngredients(2);

            Console.WriteLine($"Scaled Recipe: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("Steps:");
            foreach (Step step in recipe.Steps)
            {
                Console.WriteLine($"Step {step.Number}: {step.Description}");
            }

            recipe.ResetQuantities();

            recipe.ClearData();
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double OriginalQuantity { get; set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            OriginalQuantity = quantity;
        }
    }

    public class Step
    {
        public int Number { get; set; }
        public string Description { get; set; }

        public Step(int number, string description)
        {
            Number = number;
            Description = description;
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public Ingredient[] Ingredients { get; set; }
        public Step[] Steps { get; set; }

        public Recipe()
        {
            Name = "";
            Ingredients = new Ingredient[0];
            Steps = new Step[0];
        }

        public void ScaleIngredients(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
        }

        public void ClearData()
        {
            Name = "";
            Ingredients = new Ingredient[0];
            Steps = new Step[0];
        }
    }
}